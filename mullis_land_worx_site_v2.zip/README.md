# Mullis Land Worx — static site
Upload the contents of this folder to your GitHub Pages repository root.
- Edit phone/email in `script.js` and `footer` if needed.
- Replace `logo.jpg` in the repo with your real logo (already present in your repo).

Pages included:
- index.html (Home)
- grading.html
- concrete.html
- masonry.html
- landscaping.html
- contact.html
- styles.css
- script.js
