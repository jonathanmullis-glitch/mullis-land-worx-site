
function toggleMenu(){
  document.querySelector('.site-header').classList.toggle('open');
}
