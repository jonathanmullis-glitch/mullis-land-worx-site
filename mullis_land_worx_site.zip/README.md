# Mullis Land Worx – static site

Upload the contents of this folder to your GitHub Pages repo root.
